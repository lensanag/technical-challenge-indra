const server = require("./src/app");

const serverless = require("serverless-http");

const app = server();

module.exports.handler = serverless(app);
