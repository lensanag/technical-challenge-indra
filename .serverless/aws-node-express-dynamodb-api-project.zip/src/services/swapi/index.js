var people = require("./people");
var films = require("./films");
var swapi = {
  people,
  films,
};
module.exports = swapi;
